
  # Culture In Indonesia - SMA Taruna Nusantara Kampus Malang

  This is a code bundle for Culture In Indonesia - SMA Taruna Nusantara Kampus Malang. The original project is available at https://www.figma.com/design/lXWFAFBc24laUxa0XLiM9c/Culture-In-Indonesia---SMA-Taruna-Nusantara-Kampus-Malang.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  